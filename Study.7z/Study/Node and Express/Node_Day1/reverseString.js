	exports.reverse = function(value) { // exports to export function
		var reverseVal = ""
		for (var i = value.length - 1; i >= 0; i--) {
			reverseVal = reverseVal + value[i];
		}
		console.log("Reverse Val = ", reverseVal)
		return reverseVal
	}