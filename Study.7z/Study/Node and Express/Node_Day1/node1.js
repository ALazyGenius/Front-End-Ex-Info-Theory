var http : require('http'); //fetching the http module and creating its local instance
var server = http.createServer(function(request,response) {
	//response.writeHead(200, {"Content-Type":"text/html"});
	response.write("WELCOME TO NODE"); //response obj cretaed
	response.end(); //response ended req cycle completed
})
console.log("Server Started");
server.listen(3000);