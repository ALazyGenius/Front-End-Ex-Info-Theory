	var http = require("http"); //fetching the http module and creating its local instance
	var module = require('./authentication.js'); // import file
	var server = http.createServer(function(request,response) {
		response.writeHead(200, {"Content-Type":"text/html"}); //styling
		var result1 = module.authenticateUser('admin','admin'); // call functuon
		var result2 = module.sum(15,10);
		response.write(result1 + " " + result2); //response obj cretaed
		console.log("Result recieved")
	})
console.log("Server Started");
server.listen(3000); //port number