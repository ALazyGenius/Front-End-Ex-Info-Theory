exports.authenticateUser = function(username, password) { // exports to export function
		if(username === 'admin' && password === "admin") {
			return "Valid User"
		}
		else {
			return "Invalid User"
		}
	}

	exports.sum = function(a,b) {
		return (a+b)
	}