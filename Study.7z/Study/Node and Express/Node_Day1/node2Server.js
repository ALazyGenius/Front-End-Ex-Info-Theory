var http = require('http'); //fetching the http module and creating its local instance
var server = http.createServer(function(request,response) {
	response.writeHead(200, {"Content-Type":"text/html"});
	response.write("<html><body><h1>WELCOME TO NODE</h1></body></html>"); //response obj cretaed
	response.write(" AND EXPRESS");
	response.end(); //response ended req cycle completed
})
console.log("Server Started");
server.listen(3000); // port number