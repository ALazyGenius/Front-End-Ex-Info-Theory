	var http = require("http"); //fetching the http module and creating its local instance
	var module = require('./reverseString.js'); // import file
	var server = http.createServer(function(request,response) {
		response.writeHead(200, {"Content-Type":"text/html"}); //styling
		var reverseVal = module.reverse('admin'); // call functuon
		console.log("Inside Function");
		response.write("Reverse is " + reverseVal); //response obj cretaed
		console.log("Result recieved")
	})
console.log("Server Started");
server.listen(3000); //port number