exports.authenticateUser = function(username,password) {
			if(username === "admin" && password === "admin") {
				return "Valid User";
			}
			else {
				return "Invalid User";
			}
		}
exports.authenticatePassword = function(pass1,pass2) {
	if(pass1 === pass2) {
		return "Registration Successful";
	}
	else {
		return "Registration Not Successful. Password Don't Match!";
	}
}
