var express = require("express");
var app = express();

app.get('/',function(req,res) {
	console.log("Welcome to express");
	res.send("Welcome to express");
})
app.get('/login',function(req,res) {
	console.log("Welcome to Login");
	res.send("Welcome to Login");
})
app.get('/signup',function(req,res) {
	console.log("Welcome to signup");
	res.send("Welcome to signup");
})

app.listen(3000);
console.log("Server satrted at port 3000")