var express = require("express");
var path = require("path");
var app = express();

app.get('/',function(req,res) {
	console.log("Welcome to express");
	res.sendFile(path.join(__dirname+'/home.html'));
})
app.get('/login',function(req,res) {
	//console.log("Welcome to Login");
	res.sendFile(path.join(__dirname+'/login.html'));
})
app.get('/signup',function(req,res) {
	//console.log("Welcome to signup");
	res.sendFile(path.join(__dirname+'/signup.html'));
})

app.listen(3000);
console.log("Server satrted at port 3000");